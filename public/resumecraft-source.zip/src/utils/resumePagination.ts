import { ResumeData, WorkExperience, ProjectItem } from '../types';

export interface PageSplitResult {
  page1: ResumeData;
  page2: ResumeData;
}

/**
 * Intelligently balances resume content across two distinct A4 pages so that:
 * 1. 100% of candidate content is preserved (nothing is omitted or lost).
 * 2. Page 1 does NOT run into the bottom edge; it leaves comfortable breathing room
 *    (~250px - 450px of clean space) before continuing on Page 2.
 * 3. Page 2 has a professional continuation header and cleanly formats
 *    the remaining experiences, projects, credentials, honors, and interests.
 */
export function getResumePageData(
  data: ResumeData,
  pageNumber: 1 | 2,
  totalPages: 1 | 2 = 1
): ResumeData {
  if (totalPages === 1 || (pageNumber === 1 && totalPages <= 1)) {
    return {
      ...data,
      pageNumber: 1,
      totalPages: 1
    };
  }

  const experiences = data.experience || [];
  const projects = data.projects || [];
  const education = data.education || [];
  const achievements = data.achievements || [];
  const skills = data.skills || [];
  const certifications = data.certifications || [];
  const languages = data.languages || [];
  const hobbies = data.hobbies || [];

  // =========================================================================
  // 1. WORK EXPERIENCE & PROJECTS PARTITIONING
  // If experiences fit on Page 1 (up to 3 standard roles), KEEP ALL OF THEM
  // on Page 1! Never split them prematurely to leave Page 1 half empty and
  // create an orphaned experience item on Page 2.
  // =========================================================================
  let p1Exp: WorkExperience[] = [];
  let p2Exp: WorkExperience[] = [];
  let p1Projects: ProjectItem[] = [];
  let p2Projects: ProjectItem[] = [];

  const totalExpDescLength = experiences.reduce(
    (acc, e) => acc + (e.description?.length || 0),
    0
  );

  if (experiences.length <= 3 && totalExpDescLength < 1300) {
    // Standard resume: All work experience completes cleanly on Page 1!
    // Page 2 will focus exclusively on Projects, Honors, Certifications, etc.
    p1Exp = experiences;
    p2Exp = []; // ZERO experience on Page 2: No repetition, no orphaned jobs!
    p1Projects = [];
    p2Projects = projects;
  } else if (experiences.length > 3) {
    // Senior candidate with 4+ roles:
    // Page 1 gets top 3 primary recent roles
    // Page 2 gets earlier career history
    p1Exp = experiences.slice(0, 3);
    p2Exp = experiences.slice(3);
    p1Projects = [];
    p2Projects = projects;
  } else {
    // 2-3 unusually long roles (>1300 chars description)
    p1Exp = experiences.slice(0, 2);
    p2Exp = experiences.slice(2);
    p1Projects = [];
    p2Projects = projects;
  }

  // If candidate has 0 work experience (e.g. Student / Graduate):
  if (experiences.length === 0) {
    if (projects.length >= 2) {
      p1Projects = [projects[0]];
      p2Projects = projects.slice(1);
    } else {
      p1Projects = projects;
      p2Projects = [];
    }
  }

  // =========================================================================
  // 2. SUPPORTING SECTIONS PARTITIONING (ZERO DUPLICATION)
  // Page 1: Profile Header, Summary, All Work Experience, Core Skills, Education
  // Page 2: Clean 1-Line Running Header, Projects, Achievements, Certifications, Languages, Interests
  // =========================================================================
  const p1Skills = skills;
  const p2Skills: typeof skills = [];
  const p1Edu = education;
  const p2Edu: typeof education = [];

  // =========================================================================
  // PAGE 1
  // =========================================================================
  if (pageNumber === 1) {
    return {
      ...data,
      pageNumber: 1,
      totalPages: 2,
      personalInfo: {
        ...data.personalInfo
      },
      summary: data.summary,
      experience: p1Exp,
      skills: p1Skills,
      education: p1Edu,
      projects: p1Projects,
      achievements: [],
      certifications: [],
      languages: [],
      hobbies: []
    };
  }

  // =========================================================================
  // PAGE 2 (Strict Continuation - Zero Duplication of Profile or Experience)
  // =========================================================================
  return {
    ...data,
    pageNumber: 2,
    totalPages: 2,
    personalInfo: {
      ...data.personalInfo
      // Professional title is preserved cleanly without any appended suffix
    },
    summary: '', // Career summary completed on Page 1
    experience: p2Exp, // Empty if experiences fit on Page 1 (No duplicate experience!)
    skills: p2Skills, // Core skills completed on Page 1
    education: p2Edu, // Academic credentials completed on Page 1
    projects: p2Projects, // Featured projects with tech stacks and links
    achievements: achievements, // All awards, honors, recognitions
    certifications: certifications, // All professional credentials & licenses
    languages: languages, // All languages
    hobbies: hobbies // All interests & activities
  };
}

