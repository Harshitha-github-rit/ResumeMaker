import React, { useState, useRef, useEffect, useCallback } from 'react';
import { useResume } from '../../context/ResumeContext';
import { TemplateRenderer } from '../templates/TemplateRenderer';
import { ZoomIn, ZoomOut, RotateCcw, Maximize2, ShieldCheck, Eye, Sparkles, CheckCircle2 } from 'lucide-react';

export const ResumePreview: React.FC = () => {
  const { currentResume, updateCustomization } = useResume();
  const containerRef = useRef<HTMLDivElement>(null);
  const sheetRef = useRef<HTMLDivElement>(null);
  const [isOverOnePage, setIsOverOnePage] = useState<boolean>(false);
  const [isUnderFilled, setIsUnderFilled] = useState<boolean>(false);

  const [previewPages, setPreviewPages] = useState<1 | 2>(1);
  const [pageViewMode, setPageViewMode] = useState<'fit' | 'a4'>('fit');

  // Monitor sheet height to warn user if content extends past 1 page or is underfilled
  useEffect(() => {
    if (!sheetRef.current) return;
    const checkHeight = () => {
      if (sheetRef.current) {
        // 1123px is standard 297mm A4 height at 96 DPI
        const height = sheetRef.current.scrollHeight;
        setIsOverOnePage(height > 1130);
        setIsUnderFilled(height < 850);
      }
    };
    checkHeight();
    const observer = new ResizeObserver(checkHeight);
    observer.observe(sheetRef.current);
    return () => observer.disconnect();
  }, [currentResume, pageViewMode]);

  const handleFitToOnePage = () => {
    setPreviewPages(1);
    updateCustomization({
      spacing: 'tight',
      fontSize: 'compact',
      margins: 'compact'
    });
  };

  const handleBalanceFillPage = () => {
    updateCustomization({
      spacing: 'relaxed',
      margins: 'wide',
      fontSize: currentResume.customization?.fontSize === 'compact' ? 'normal' : currentResume.customization?.fontSize || 'normal'
    });
  };

  // Compute auto-fit scale based on available container width
  const calculateFitScale = useCallback(() => {
    if (!containerRef.current) {
      if (typeof window !== 'undefined' && window.innerWidth < 768) {
        return Math.max(0.38, Math.min(0.65, (window.innerWidth - 32) / 794));
      }
      return 0.85;
    }
    const containerWidth = containerRef.current.clientWidth;
    // 794px is standard A4 paper width (210mm at 96 DPI)
    const padding = containerWidth < 640 ? 24 : 48;
    const targetScale = (containerWidth - padding) / 794;
    return Math.max(0.35, Math.min(1.1, Number(targetScale.toFixed(2))));
  }, []);

  const [zoomLevel, setZoomLevel] = useState<number>(() => {
    if (typeof window !== 'undefined' && window.innerWidth < 768) {
      return Math.max(0.38, Math.min(0.6, (window.innerWidth - 24) / 794));
    }
    return 0.85;
  });

  // Automatically adapt to mobile screen on load and resize
  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth < 768) {
        const fit = calculateFitScale();
        setZoomLevel(fit);
      }
    };

    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, [calculateFitScale]);

  const handleZoomIn = () => setZoomLevel((prev) => Math.min(Number((prev + 0.1).toFixed(2)), 1.5));
  const handleZoomOut = () => setZoomLevel((prev) => Math.max(Number((prev - 0.1).toFixed(2)), 0.35));
  const handleFitPage = () => {
    const fit = calculateFitScale();
    setZoomLevel(fit);
  };
  const handleActualSize = () => setZoomLevel(1.0);
  const handleResetZoom = () => setZoomLevel(0.85);

  const templateName = currentResume.customization?.template || 'modern';
  const accentColor = currentResume.customization?.accentColor || '#2563eb';

  return (
    <div className="flex flex-col h-full bg-slate-200/70 relative">
      {/* Top Preview Controls Toolbar */}
      <div className="p-2.5 sm:p-3 bg-white/95 backdrop-blur border-b border-slate-200 flex flex-wrap items-center justify-between gap-2 z-10 shrink-0">
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5 text-xs font-bold text-slate-800">
            <Eye className="w-3.5 h-3.5 text-blue-600" />
            <span>A4 Preview</span>
          </div>

          <span className="text-slate-300 hidden sm:inline">|</span>

          {/* Active Template Chip */}
          <div className="flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-slate-100 border border-slate-200 text-[11px] font-semibold text-slate-700 capitalize">
            <span
              className="w-2 h-2 rounded-full shrink-0"
              style={{ backgroundColor: accentColor }}
            />
            <span className="truncate max-w-[90px] sm:max-w-none">{templateName}</span>
          </div>

          {/* Page Layout Selector (1 Page vs 2 Pages) */}
          <div className="flex items-center bg-slate-100 rounded-lg p-0.5 border border-slate-200 text-xs">
            <button
              type="button"
              onClick={() => setPreviewPages(1)}
              className={`px-2 py-0.5 rounded-md font-bold transition-all cursor-pointer ${
                previewPages === 1
                  ? 'bg-white text-blue-700 shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
              title="View as standard 1-page resume"
            >
              1 Page
            </button>
            <button
              type="button"
              onClick={() => setPreviewPages(2)}
              className={`px-2 py-0.5 rounded-md font-bold transition-all cursor-pointer ${
                previewPages === 2
                  ? 'bg-white text-blue-700 shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
              title="View as balanced 2-page resume"
            >
              2 Pages
            </button>
          </div>

          {/* View Mode: Fit Content vs Full A4 (active when 1 Page is selected) */}
          {previewPages === 1 && (
            <div className="flex items-center bg-slate-100 rounded-lg p-0.5 border border-slate-200 text-xs">
              <button
                type="button"
                onClick={() => setPageViewMode('fit')}
                className={`px-2 py-0.5 rounded-md font-medium transition-all cursor-pointer ${
                  pageViewMode === 'fit'
                    ? 'bg-white text-blue-700 shadow-2xs font-bold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
                title="Fits height naturally to content - eliminates excess blank space at bottom"
              >
                Fit Content
              </button>
              <button
                type="button"
                onClick={() => setPageViewMode('a4')}
                className={`px-2 py-0.5 rounded-md font-medium transition-all cursor-pointer ${
                  pageViewMode === 'a4'
                    ? 'bg-white text-blue-700 shadow-2xs font-bold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
                title="Full A4 print frame (210 × 297 mm)"
              >
                Full A4
              </button>
            </div>
          )}

          {/* Underfilled Auto-Fill recommendation button */}
          {previewPages === 1 && isUnderFilled && pageViewMode === 'a4' && (
            <button
              type="button"
              onClick={handleBalanceFillPage}
              title="Content is short! Click to evenly expand spacing and fill the A4 sheet nicely"
              className="flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-blue-600 hover:bg-blue-700 text-white text-[11px] font-bold shadow-xs transition-all cursor-pointer"
            >
              <Sparkles className="w-3 h-3 text-blue-200" />
              <span>Auto-Fill Page</span>
            </button>
          )}

          {/* Page status badge */}
          {previewPages === 1 && isOverOnePage ? (
            <button
              type="button"
              onClick={handleFitToOnePage}
              title="Click to automatically tighten margins & font size to fit on 1 single page"
              className="flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-amber-500 hover:bg-amber-600 text-white text-[11px] font-bold shadow-xs transition-all cursor-pointer animate-pulse"
            >
              <Sparkles className="w-3 h-3 text-amber-200" />
              <span>Fit to 1 Page</span>
            </button>
          ) : (
            <div className="hidden sm:flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-50 border border-emerald-200 text-[11px] font-bold text-emerald-700">
              <CheckCircle2 className="w-3 h-3 text-emerald-600" />
              <span>{previewPages === 1 ? (pageViewMode === 'fit' ? 'Content Fit' : '1 Page Fit') : '2 Pages Balanced'}</span>
            </div>
          )}

          <div className="hidden md:flex items-center gap-1 px-2 py-0.5 rounded-full bg-slate-100 border border-slate-200 text-[11px] font-bold text-slate-600">
            <ShieldCheck className="w-3 h-3 text-emerald-600" />
            <span>ATS 99%</span>
          </div>
        </div>

        {/* Zoom Stepper & Fit Controls */}
        <div className="flex items-center gap-1 bg-slate-100 rounded-lg p-1">
          <button
            type="button"
            onClick={handleFitPage}
            title="Auto-Fit Page to Screen"
            className="px-2 py-1 rounded text-[11px] font-bold text-slate-700 hover:text-blue-600 hover:bg-white transition-all cursor-pointer flex items-center gap-1"
          >
            <Maximize2 className="w-3 h-3" />
            <span className="hidden xs:inline">Fit</span>
          </button>

          <button
            type="button"
            onClick={handleActualSize}
            title="100% Actual Print Size"
            className="px-1.5 py-1 rounded text-[11px] font-mono text-slate-600 hover:text-slate-900 hover:bg-white transition-all cursor-pointer"
          >
            100%
          </button>

          <span className="w-px h-3.5 bg-slate-300 mx-0.5" />

          <button
            type="button"
            onClick={handleZoomOut}
            title="Zoom Out"
            className="p-1 rounded text-slate-600 hover:text-slate-900 hover:bg-white transition-all cursor-pointer"
          >
            <ZoomOut className="w-3.5 h-3.5" />
          </button>

          <span className="text-[11px] font-mono text-slate-700 w-9 text-center select-none font-bold">
            {Math.round(zoomLevel * 100)}%
          </span>

          <button
            type="button"
            onClick={handleZoomIn}
            title="Zoom In"
            className="p-1 rounded text-slate-600 hover:text-slate-900 hover:bg-white transition-all cursor-pointer"
          >
            <ZoomIn className="w-3.5 h-3.5" />
          </button>

          <button
            type="button"
            onClick={handleResetZoom}
            title="Reset Zoom to 85%"
            className="p-1 rounded text-slate-400 hover:text-slate-700 hover:bg-white transition-all cursor-pointer"
          >
            <RotateCcw className="w-3 h-3" />
          </button>
        </div>
      </div>

      {/* Sheet Display Stage */}
      <div
        ref={containerRef}
        className="flex-1 overflow-auto p-3 sm:p-8 flex justify-center items-start"
      >
        <div
          style={{
            transform: `scale(${zoomLevel})`,
            transformOrigin: 'top center',
            transition: 'transform 0.12s ease-out'
          }}
          className="shrink-0"
        >
          {previewPages === 1 ? (
            /* Single Page Sheet */
            <div
              ref={sheetRef}
              id="printable-resume-container"
              className={`w-[210mm] ${
                pageViewMode === 'fit' ? 'min-h-0' : 'min-h-[297mm]'
              } bg-white text-slate-900 shadow-2xl rounded-xs overflow-hidden relative transition-all duration-150`}
              style={{
                boxShadow: '0 10px 25px -5px rgba(0, 0, 0, 0.15), 0 8px 10px -6px rgba(0, 0, 0, 0.1)'
              }}
            >
              <TemplateRenderer data={currentResume} resume={currentResume} totalPages={1} />
            </div>
          ) : (
            /* 2-Page Clean Balanced Sheets */
            <div id="printable-resume-container" className="flex flex-col gap-8 items-center">
              {/* Page 1 */}
              <div className="relative">
                <div className="text-xs font-semibold text-slate-500 mb-1.5 flex items-center justify-between px-1">
                  <span className="font-bold">Page 1 of 2 — Summary, Experience, Education & Skills</span>
                  <span className="text-[10px] bg-slate-200 text-slate-700 px-1.5 py-0.5 rounded font-mono">210 × 297 mm</span>
                </div>
                <div
                  id="printable-resume-page-1"
                  className="w-[210mm] min-h-[297mm] bg-white text-slate-900 shadow-2xl rounded-xs overflow-hidden relative"
                  style={{
                    boxShadow: '0 10px 25px -5px rgba(0, 0, 0, 0.15), 0 8px 10px -6px rgba(0, 0, 0, 0.1)'
                  }}
                >
                  <TemplateRenderer data={currentResume} resume={currentResume} page={1} totalPages={2} />
                  <div className="absolute bottom-3 right-4 text-[10px] text-slate-400 font-mono">Page 1 of 2</div>
                </div>
              </div>

              {/* Visual Page Break Separator */}
              <div className="w-full flex items-center gap-3 py-1 select-none">
                <div className="h-px bg-slate-300 flex-1 border-dashed border-t border-slate-300" />
                <span className="text-[10px] font-mono tracking-wider uppercase text-slate-400 px-2 py-0.5 bg-slate-100 rounded-full border border-slate-200">
                  Page Break • No Cards Cut
                </span>
                <div className="h-px bg-slate-300 flex-1 border-dashed border-t border-slate-300" />
              </div>

              {/* Page 2 */}
              <div className="relative">
                <div className="text-xs font-semibold text-slate-500 mb-1.5 flex items-center justify-between px-1">
                  <span className="font-bold">Page 2 of 2 — Continued Experience, Projects, Honors & Credentials</span>
                  <span className="text-[10px] bg-slate-200 text-slate-700 px-1.5 py-0.5 rounded font-mono">210 × 297 mm</span>
                </div>
                <div
                  id="printable-resume-page-2"
                  className="w-[210mm] min-h-[297mm] bg-white text-slate-900 shadow-2xl rounded-xs overflow-hidden relative"
                  style={{
                    boxShadow: '0 10px 25px -5px rgba(0, 0, 0, 0.15), 0 8px 10px -6px rgba(0, 0, 0, 0.1)'
                  }}
                >
                  <TemplateRenderer data={currentResume} resume={currentResume} page={2} totalPages={2} />
                  <div className="absolute bottom-3 right-4 text-[10px] text-slate-400 font-mono">Page 2 of 2</div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Floating page format indicator */}
      <div className="absolute bottom-3 right-3 z-10 px-2.5 py-1 rounded-full bg-slate-900/80 backdrop-blur text-white text-[10px] font-semibold tracking-wide shadow-md pointer-events-none flex items-center gap-1.5">
        <Sparkles className="w-2.5 h-2.5 text-amber-400" />
        <span>
          {previewPages === 2
            ? '2 Pages Balanced (210 × 297 mm)'
            : pageViewMode === 'fit'
            ? 'Content Fit • No Awkward Empty Gap'
            : 'A4 Format (210 × 297 mm)'}
        </span>
      </div>
    </div>
  );
};
