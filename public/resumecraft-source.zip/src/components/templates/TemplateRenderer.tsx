import React from 'react';
import { ResumeData } from '../../types';
import { DEFAULT_RESUME } from '../../data/sampleResumes';
import { ModernTemplate } from './ModernTemplate';
import { ClassicTemplate } from './ClassicTemplate';
import { MinimalTemplate } from './MinimalTemplate';
import { ExecutiveTemplate } from './ExecutiveTemplate';
import { CreativeTemplate } from './CreativeTemplate';
import { ProfessionalTemplate } from './ProfessionalTemplate';

import { getResumePageData } from '../../utils/resumePagination';

interface Props {
  data?: ResumeData;
  resume?: ResumeData;
  className?: string;
  page?: 1 | 2;
  totalPages?: 1 | 2;
}

export const TemplateRenderer: React.FC<Props> = ({
  data,
  resume,
  className = '',
  page = 1,
  totalPages = 1
}) => {
  const activeResume: ResumeData = data || resume || DEFAULT_RESUME;
  const validPage: 1 | 2 = page === 2 ? 2 : 1;
  const pageResume = totalPages === 2 ? getResumePageData(activeResume, validPage, 2) : activeResume;
  const safeCustomization = pageResume.customization || DEFAULT_RESUME.customization;
  const templateId = safeCustomization.template || 'modern';

  const renderTemplate = () => {
    switch (templateId) {
      case 'classic':
        return <ClassicTemplate data={pageResume} page={validPage} totalPages={totalPages} />;
      case 'minimal':
        return <MinimalTemplate data={pageResume} page={validPage} totalPages={totalPages} />;
      case 'executive':
        return <ExecutiveTemplate data={pageResume} page={validPage} totalPages={totalPages} />;
      case 'creative':
        return <CreativeTemplate data={pageResume} page={validPage} totalPages={totalPages} />;
      case 'professional':
        return <ProfessionalTemplate data={pageResume} page={validPage} totalPages={totalPages} />;
      case 'modern':
      default:
        return <ModernTemplate data={pageResume} page={validPage} totalPages={totalPages} />;
    }
  };

  return (
    <div className={`w-full overflow-hidden bg-white shadow-xl print:shadow-none print:w-full ${className}`}>
      {renderTemplate()}
    </div>
  );
};
